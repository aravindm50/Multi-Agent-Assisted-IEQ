function fn_Display_wall(block)
setup(block); %% Call the setup(.) once & initialize
% Sub-functions are defined below
%% Inner Sub_Fn-1 ============================================================================
%% setup(.) is called only once at the start of simulation
    function setup(block)
        % Register the number of in & out ports.
        block.NumInputPorts  = 0;   block.NumOutputPorts = 0;
        % Set up the i/o port properties to be inherited, ie. dynamic.
        block.SetPreCompInpPortInfoToDynamic;   block.SetPreCompOutPortInfoToDynamic;
        % Register the parameters.
        block.NumDialogPrms= 0;  %block.DialogPrmsTunable = {'Tunable'};
        block.SetAccelRunOnTLC(false); block.SimStateCompliance = 'DefaultSimState';
        block.RegBlockMethod('Outputs', @Outputs); %% Assign the output_function to be called each time
    end
%% Inner Sub_Fn-2 ============================================================================
%% output(.) is called for each time-step of simulation
%% The number of time is is called in a time-step depends on Solver for ODE
%% Ex: ode1 (Euler) calls output(.) only once in each time-step.
    function Outputs(block)
        %path = strcat(gcs,'Subsystem');
        
        Display_Block1=get_param(gcb,'Parent');
        C = strsplit(Display_Block1,'/');
        Display_Block = get_param(gcs,'Parent');
        switch cell2mat(C(end))
            
            case 'Left_Wall'
                Temperature_2=get_param(strcat(Display_Block,'/Tout3'),'Value');
                Display_String=['Temperature \n Left Room= \n'   num2str(Temperature_2,'%.2f')   ' deg. K\n' ];
            case 'Right_Wall'
                Temperature_2=get_param(strcat(Display_Block,'/Tout1'),'Value');
                Display_String=['Temperature \n Right Room= \n'   num2str(Temperature_2,'%.2f')   ' deg. K\n' ];
            case 'Front_Wall'
                Temperature_2=get_param(strcat(Display_Block,'/Tout2'),'Value');
                Display_String=['Temperature Corridor= '   num2str(Temperature_2,'%.2f')   ' deg. K\n' ];
            case 'Back_Wall'
                Temperature_2=get_param(strcat(Display_Block,'/Tout'),'Bias');
                Display_String=['Temperature Outside= '   num2str(Temperature_2,'%.2f')   ' deg. K\n' ];
            case 'Roof'
                Temperature_2=get_param(strcat(Display_Block,'/Tout5'),'Value');
                Display_String=['Temperature \n Above Roof= \n'   num2str(Temperature_2,'%.2f')   ' deg. K\n' ];
            case 'Floor'
                Temperature_2=get_param(strcat(Display_Block,'/Tout4'),'Value');
                Display_String=['Temperature \n Below= \n'   num2str(Temperature_2,'%.2f')   ' deg. K\n' ];
        
        end 
        
        set_param(Display_Block1,'MaskDisplay',['fprintf(' char(39)  Display_String  char(39) ')']); %% Sets gray-string nearby the block
        a = jet(40);
        n = str2double(Temperature_2)-273;
        if n<50 && n>10
            set_param(Display_Block1, 'BackgroundColor', mat2str(a(n-5,:))); %% Sets background-color of the block
        else
            set_param(Display_Block1, 'BackgroundColor', mat2str(a(15,:))); %% Sets background-color of the block
        end
    end
end
%% END OF FILE