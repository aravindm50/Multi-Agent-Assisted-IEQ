#include "application.h"
#ifndef __Sensor_Array_H_
#define __Sensor_Array_H_
#include <Particle.h>

class Sensor_Array
{
	public:
	Sensor_Array();
	void channel0();	
	void channel1();
	void channel2();
	void channel3();
  
};

#endif