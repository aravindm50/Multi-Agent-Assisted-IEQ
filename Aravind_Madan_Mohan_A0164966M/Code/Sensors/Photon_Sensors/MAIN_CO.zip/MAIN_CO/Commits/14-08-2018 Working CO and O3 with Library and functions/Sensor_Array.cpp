#include "application.h"
#include "Sensor_Array.h"
//#include "Particle.h"
Sensor_Array::Sensor_Array(){}

void Sensor_Array::CO2_initialize(){
	
	pinMode(WKP,OUTPUT);
	digitalWrite(WKP, LOW);
	pinMode(D6,OUTPUT);
	pinMode(D7,OUTPUT);
	digitalWrite(D6,LOW);
	digitalWrite(D7,LOW);
	
}

void Sensor_Array::O3_initialize(){
	
	pinMode(WKP,OUTPUT);
	digitalWrite(WKP, LOW);
	pinMode(D6,OUTPUT);
	pinMode(D7,OUTPUT);
	digitalWrite(D6,HIGH);
	digitalWrite(D7,LOW);
	
}

void Sensor_Array::HCHO_initialize(){
	
	pinMode(WKP,OUTPUT);
	digitalWrite(WKP, LOW);
	pinMode(D6,OUTPUT);
	pinMode(D7,OUTPUT);
	digitalWrite(D6,LOW);
	digitalWrite(D7,HIGH);
	
}


void Sensor_Array::CO_initialize(){
	
	pinMode(WKP,OUTPUT);
	digitalWrite(WKP, LOW);
	pinMode(D6,OUTPUT);
	pinMode(D7,OUTPUT);
	digitalWrite(D6,HIGH);
	digitalWrite(D7,HIGH);
	
}


