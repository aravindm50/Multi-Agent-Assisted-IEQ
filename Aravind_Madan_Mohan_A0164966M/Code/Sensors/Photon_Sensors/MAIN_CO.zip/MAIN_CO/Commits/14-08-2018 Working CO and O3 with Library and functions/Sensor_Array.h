#include "application.h"
#ifndef __Sensor_Array_H_
#define __Sensor_Array_H_
#include <Particle.h>
/* #include <SoftwareSerial.h>*/
//#include <Arduino.h> 


class Sensor_Array
{
  public:
  Sensor_Array();
  void CO2_initialize();	
  void CO_initialize();
  void HCHO_initialize();
  //Dust_initialize();
  void O3_initialize();
  
  private:
};

#endif