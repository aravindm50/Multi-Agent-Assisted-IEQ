import serial
import time
import csv

ser = serial.Serial('COM12')
ser.flushInput()
max_readings = 100000
readings = 1
readings2 = 1
while True:
	ser_bytes = ser.readline()
	decoded_bytes = (ser_bytes[0:len(ser_bytes)-2].decode("utf-8",'ignore'))
	a = decoded_bytes.split(',')
	if (a[0] == "011518010645"):
		with open("Photon_CO.csv", "a", newline='') as csvfile:
			writer = csv.writer(csvfile, delimiter=",")
			if (len(a) > 5):
				writer.writerow([int(time.time()), a[1]])
				if readings >= max_readings:
					break
				else:
					readings = readings + 1
	elif (a[0] == "092117020557"):
		with open("Photon_O3.csv", "a", newline='') as csvfile:
			writer = csv.writer(csvfile, delimiter=",")
			if (len(a) > 5):
				writer.writerow([int(time.time()), a[1]])
				if readings2 >= max_readings:
					break
				else:
					readings2 = readings2 + 1