#include "application.h"
#include "Sensor_Array.h"
#include "SPEC.h"
//#include "Particle.h"

SPEC_Sensor::SPEC_Sensor(){}

void SPEC_Sensor::O3_init(){
	
	Serial1.end();
	Serial1.begin(9600);
	delay(5000);
	
	Serial.flush();
	Serial1.flush();
	
	Serial1.write('A');// 1) Write any characters
	delay(1000);
	Serial1.print(5);// timing, it is required although it is not mentioned in the datasheet 
	delay(1500);
	Serial1.write('\r');// 3) Write an enter character
	delay(1000);
	Serial.println();
	//Serial.println("Finished Setup");
	Serial.println("Sensor #, O3 Conc.(PPB), Temp.(C), Rh (%),Conc. (Counts), Temp. (Counts), Rh (%Counts), Days, Hours, Minutes, Seconds");
	Serial1.write('c');// 4) Write "c" for continuous sensing
	//delay(500);

}

/*
/* Setup intended for SDK which is spanned and zeroed, 
/* or has the barcode information previously entered. 
/* Must initialize both serial ports:
*/
void SPEC_Sensor::CO_init() 
{
	Serial1.end();
	Serial1.begin(9600);
	delay(5000);
	
	Serial.flush();
	Serial1.flush();
	
	Serial1.write('A'); // 1) Write any characters
	delay(1100); 
	Serial1.print(5);// 2) provide sensing period (5 second)
	delay(1500);
	Serial1.write('\r'); // 3) Write an enter character
	delay(1000);
	Serial.println();
	//Serial.println("Finished Setup");
	Serial.println("Sensor #, CO Conc.(PPB), Temp.(C), Rh (%),Conc. (Counts), Temp. (Counts), Rh (%Counts), Days, Hours, Minutes, Seconds");
	Serial1.write('c'); // 4) Write "c" for continuous sensing
	//delay(500);

}

void SPEC_Sensor::readserial()
{	
	while (Serial1.available()) // When data available read it and send it serially
	{
		int inByte = Serial1.read();
		Serial.write(inByte);	
	}
}


void SPEC_Sensor::zero_calibration(String c)
{
	/* a. When first given power after a long period of unpowered storage, the sensor needs to
	stabilize in clean air to its zero offset current.
	b. WAIT at least 1 hour in clean air while ensuring USB port has not gone to sleep. Sampling in
	continuous mode is one way to ensure this */
	
	Serial1.write('A');
	delay(1100);
	Serial1.write('Z');// timing
	delay(1500);
	if (c == "CO")
	{	
		Serial1.write('12345');
		Serial1.write('\r');
		delay(1000);
	}
	
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	