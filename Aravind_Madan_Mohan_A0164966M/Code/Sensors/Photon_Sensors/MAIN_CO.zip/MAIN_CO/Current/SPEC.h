#include "application.h"
#ifndef __SPEC_H_
#define __SPEC_H_
#include <Particle.h>
/* #include <SoftwareSerial.h>*/
//#include <Arduino.h> 


class SPEC_Sensor
{
	public:
		SPEC_Sensor();
		void O3_init();	
		void CO_init();
		void readserial();
		void zero_calibration(String c);
};

#endif