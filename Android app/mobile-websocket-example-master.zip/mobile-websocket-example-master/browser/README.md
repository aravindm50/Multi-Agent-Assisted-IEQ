# Web browser client

To serve the files on localhost, run

    python -m SimpleHTTPServer

Then navigate to http://localhost:8000
