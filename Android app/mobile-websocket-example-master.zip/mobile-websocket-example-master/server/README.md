# Server

To set up, run `bundle install`

To start the server, run `ruby server.rb`
