# Mobile websocket example

This is example code showing how to use websockets from iOS and Android, in the form of a very simple chat service.

## server

A simple websocket server written in Ruby.

## browser

Browser client in HTML and JavaScript.

## ios

iOS client in Objective-C.

## android

Android client in Java.
